import './App.css'
import MainLayout from './components/Layout/MainLayout'

function App() {
  

  return (
    <>
    <MainLayout></MainLayout>
    </>
  )
}

export default App
